import requests
import json
import os

def lambda_handler(event, context):
    try:
        # Configuration
        api_key = os.environ['GOOGLE_BOOKS_API_KEY']
        query_params = event.get('queryStringParameters', {}) or {}
        genre = query_params.get('genre', 'fiction')
        max_results = min(int(query_params.get('max_results', 5)), 10)
        
        # API Call
        url = f"https://www.googleapis.com/books/v1/volumes?q=subject:{genre}&maxResults={max_results}&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        # Process Results
        books_data = response.json()
        recommendations = []
        
        for item in books_data.get('items', []):
            info = item.get('volumeInfo', {})
            recommendations.append({
                'title': info.get('title', 'Untitled'),
                'author': ', '.join(info.get('authors', ['Unknown'])),
                'description': (info.get('description', '')[:150] + '...') if info.get('description') else 'No description',
                'image': info.get('imageLinks', {}).get('thumbnail', ''),
                'link': info.get('infoLink', '')
            })
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'status': 'success',
                'books': recommendations
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }