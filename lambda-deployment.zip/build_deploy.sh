#!/bin/bash

# Create deployment package
echo "Creating deployment package..."
mkdir -p package
pip install -r requirements.txt -t package/
cp lambda_function.py package/

# Zip the package
echo "Zipping files..."
cd package && zip -r ../lambda-deployment.zip . && cd ..

# Deploy to AWS Lambda
echo "Deploying to AWS Lambda..."
aws lambda update-function-code \
    --function-name book-recommender \
    --zip-file fileb://lambda-deployment.zip

echo "Deployment complete!"